import json
import hashlib
import time
from datetime import datetime, timezone
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../AHRP')))

from AHRP.query.engine import HistoryStore

# Capability Matrix (Deterministic Outcomes)
CAPABILITY_MATRIX = {
    "did:example:worker-alpha": {"DATA_PROCESSING": "SUCCESS", "ANALYSIS": "FAILURE", "OTHER": "SUCCESS", "CODING": "FAILURE"},
    "did:example:worker-beta": {"DATA_PROCESSING": "SUCCESS", "ANALYSIS": "TIMEOUT", "OTHER": "SUCCESS", "CODING": "SUCCESS"},
    "did:example:worker-gamma": {"DATA_PROCESSING": "SUCCESS", "ANALYSIS": "SUCCESS", "OTHER": "SUCCESS", "CODING": "SUCCESS"}
}

def deterministic_worker_simulation(task, agent):
    agent_caps = CAPABILITY_MATRIX.get(agent, {})
    return agent_caps.get(task["task_type"], "FAILURE")

def get_utc_now():
    return datetime.now(timezone.utc).isoformat()

def write_jsonl(filepath, item):
    with open(filepath, 'a') as f:
        f.write(json.dumps(item) + '\n')

def sha256_hash(data: dict) -> str:
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()

def get_fake_ahrp_history(agent_id):
    events = []
    if "worker-alpha" in agent_id:
        for i in range(2):
            events.append({
                "schema_version": "0.1.0",
                "event_id": f"evt-hist-alpha-{i}",
                "agent_reference": {"identity_source": "DBOS", "identity_ref": agent_id},
                "agent_version": "1.0.0",
                "task_type": "CODING",
                "action_type": "EXECUTE",
                "result_status": "FAILURE",
                "failure_category": "CAPABILITY_LIMIT",
                "occurred_at": get_utc_now(),
                "evidence_references": [{"source": "TITMAS_EVIDENCE", "version": "1.0", "reference_id": f"mock-ref-a{i}", "hash": "sha256:0000000000000000000000000000000000000000000000000000000000000000", "availability_status": "AVAILABLE"}],
                "verification_references": [{"verification_id": f"ver-hist-alpha-{i}", "verifier_name": "verifier-delta"}],
                "disclosure": {"disclosure_scope": "PUBLIC", "declared_by": "mock"}
            })
    if "worker-beta" in agent_id:
        events.append({
            "schema_version": "0.1.0",
            "event_id": "evt-hist-beta-1",
            "agent_reference": {"identity_source": "DBOS", "identity_ref": agent_id},
            "agent_version": "1.0.0",
            "task_type": "ANALYSIS",
            "action_type": "EXECUTE",
            "result_status": "FAILURE",
            "failure_category": "POLICY_RESTRICTION",
            "occurred_at": get_utc_now(),
            "evidence_references": [{"source": "TITMAS_EVIDENCE", "version": "1.0", "reference_id": "mock-ref-b", "hash": "sha256:0000000000000000000000000000000000000000000000000000000000000000", "availability_status": "AVAILABLE"}],
            "verification_references": [{"verification_id": "ver-hist-beta-1", "verifier_name": "verifier-delta"}],
            "disclosure": {"disclosure_scope": "PUBLIC", "declared_by": "mock"}
        })
    return events

def get_fake_verifications(agent_id):
    verifications = []
    if "worker-alpha" in agent_id:
        for i in range(2):
            verifications.append({
                "schema_version": "0.1.0",
                "verification_id": f"ver-hist-alpha-{i}",
                "verifier": {"verifier_name": "verifier-delta", "verifier_class": "INDEPENDENT_AGENT"},
                "verification_type": "EVENT_CONFIRMATION",
                "verification_status": "VERIFIED",
                "verified_at": get_utc_now(),
                "scope": {"subject_event_id": f"evt-hist-alpha-{i}", "subject_type": "EXPERIENCE_EVENT", "covered_aspect": "FULL_EVENT", "agent_ref": agent_id, "agent_version": "1.0.0"},
                "self_verification": False,
                "authorization_effect": "NONE"
            })
    if "worker-beta" in agent_id:
        verifications.append({
            "schema_version": "0.1.0",
            "verification_id": "ver-hist-beta-1",
            "verifier": {"verifier_name": "verifier-delta", "verifier_class": "INDEPENDENT_AGENT"},
            "verification_type": "EVENT_CONFIRMATION",
            "verification_status": "VERIFIED",
            "verified_at": get_utc_now(),
            "scope": {"subject_event_id": "evt-hist-beta-1", "subject_type": "EXPERIENCE_EVENT", "covered_aspect": "FULL_EVENT", "agent_ref": agent_id, "agent_version": "1.0.0"},
            "self_verification": False,
            "authorization_effect": "NONE"
        })
    return verifications

def simulate_ahrp_query_integration(engine, task, agent):
    events_raw = engine.query_events(identity_ref=agent)
    
    if not events_raw:
        return {"decision_changed": False, "reason": "Rule D: COLD_START_CONSERVATIVE (NO_RECORD)", "new_agent": agent, "ref": []}
    
    events = []
    for evt in events_raw:
        if isinstance(evt, str):
             break
        events.append(evt)
        
    for evt in events:
         if evt.get("failure_category") == "POLICY_RESTRICTION" and evt.get("verification_independence", {}).get("independence_class", "INDEPENDENT") == "INDEPENDENT":
             if task["risk_level"] == "HIGH":
                  return {"decision_changed": True, "reason": "Rule B: POLICY_RESTRICTION_BLOCK", "new_agent": "did:example:worker-gamma", "ref": [evt["event_id"]]}

    cap_limit_count = 0
    cap_limit_refs = []
    for evt in events:
         if evt.get("failure_category") == "CAPABILITY_LIMIT" and evt.get("task_type") == task["task_type"]:
             if evt.get("verification_independence", {}).get("independence_class", "INDEPENDENT") == "INDEPENDENT":
                  cap_limit_count += 1
                  cap_limit_refs.append(evt["event_id"])
                  if cap_limit_count >= 2:
                      return {"decision_changed": True, "reason": "Rule A: CAPABILITY_LIMIT_VETO", "new_agent": "did:example:worker-beta", "ref": cap_limit_refs}

    return {"decision_changed": False, "reason": "AHRP history acceptable", "new_agent": agent, "ref": []}

def write_evidence_file(task_id, outcome, agent):
    evidence_path = f"experiments/ahrp-pilot-readiness-v0.2-method-fix/evidence/executions/evt-run-{task_id}.txt"
    content = f"Execution Evidence for {task_id}\nAgent: {agent}\nOutcome: {outcome}\nTime: {get_utc_now()}\n"
    with open(evidence_path, "w") as f:
         f.write(content)
    with open(evidence_path, "rb") as f:
         file_hash = "sha256:" + hashlib.sha256(f.read()).hexdigest()
    return f"evt-run-{task_id}.txt", file_hash

def main():
    for f in ["data/actual-executions.jsonl", "data/pre-query-decisions.jsonl", "data/post-query-decisions.jsonl", "data/experience-events.jsonl", "data/verification-records.jsonl"]:
        path = os.path.join("experiments/ahrp-pilot-readiness-v0.2-method-fix", f)
        if os.path.exists(path):
            os.remove(path)

    engine = HistoryStore()
    for agent in ["did:example:worker-alpha", "did:example:worker-beta", "did:example:worker-gamma"]:
         for evt in get_fake_ahrp_history(agent):
             engine.ingest_event(evt)
         for ver in get_fake_verifications(agent):
             engine.ingest_verification(ver)

    tasks_file = "experiments/ahrp-pilot-readiness-v0.2-method-fix/data/tasks.jsonl"
    pre_query_file = "experiments/ahrp-pilot-readiness-v0.2-method-fix/data/pre-query-decisions.jsonl"
    post_query_file = "experiments/ahrp-pilot-readiness-v0.2-method-fix/data/post-query-decisions.jsonl"
    executions_file = "experiments/ahrp-pilot-readiness-v0.2-method-fix/data/actual-executions.jsonl"
    experience_events_file = "experiments/ahrp-pilot-readiness-v0.2-method-fix/data/experience-events.jsonl"
    
    monotonic_seq = 1

    with open(tasks_file, 'r') as f:
        tasks = [json.loads(line) for line in f]

    for i, task in enumerate(tasks):
        is_no_ahrp_arm = (i % 2 == 0)
        initial_agent = task["candidate_agents"][i % len(task["candidate_agents"])]
        
        if is_no_ahrp_arm:
            final_agent = initial_agent
            outcome = deterministic_worker_simulation(task, final_agent)
            write_jsonl(executions_file, {
                "task_id": task["task_id"],
                "arm": "No-AHRP",
                "agent": final_agent,
                "outcome": outcome,
                "recorded_at": get_utc_now()
            })
            
        else:
            pre_query_record = {
                "task_id": task["task_id"],
                "candidate_agents": task["candidate_agents"],
                "selected_agent_before_query": initial_agent,
                "selection_reason_before_query": "Naive selection",
                "recorded_at": get_utc_now(),
                "monotonic_sequence": monotonic_seq
            }
            pre_query_record["record_hash"] = sha256_hash(pre_query_record)
            write_jsonl(pre_query_file, pre_query_record)
            # simulate writing/fsync
            time.sleep(0.001)
            monotonic_seq += 1
            
            query_result = simulate_ahrp_query_integration(engine, task, initial_agent)
            
            post_query_record = {
                "task_id": task["task_id"],
                "pre_query_record_hash": pre_query_record["record_hash"],
                "ahrp_query_id": f"q-{task['task_id']}",
                "selected_agent_after_query": query_result["new_agent"],
                "selection_reason_after_query": query_result["reason"],
                "decision_changed": query_result["decision_changed"],
                "supporting_event_references": query_result["ref"],
                "recorded_at": get_utc_now(),
                "monotonic_sequence": monotonic_seq
            }
            post_query_record["record_hash"] = sha256_hash(post_query_record)
            write_jsonl(post_query_file, post_query_record)
            time.sleep(0.001)
            monotonic_seq += 1
            
            final_agent = query_result["new_agent"]
            outcome = deterministic_worker_simulation(task, final_agent)
            
            write_jsonl(executions_file, {
                "task_id": task["task_id"],
                "arm": "AHRP-assisted",
                "agent": final_agent,
                "outcome": outcome,
                "recorded_at": get_utc_now()
            })
            
        ref_id, ref_hash = write_evidence_file(task["task_id"], outcome, final_agent)
        
        exp_evt = {
            "schema_version": "0.1.0",
            "event_id": f"evt-run-{task['task_id']}",
            "agent_reference": {"identity_source": "DBOS", "identity_ref": final_agent},
            "agent_version": "1.0.0",
            "task_type": task["task_type"],
            "action_type": "EXECUTE",
            "result_status": outcome,
            "failure_category": "NOT_APPLICABLE" if outcome == "SUCCESS" else "CAPABILITY_LIMIT",
            "occurred_at": get_utc_now(),
            "evidence_references": [{"source": "TITMAS_EVIDENCE", "version": "1.0", "reference_id": ref_id, "hash": ref_hash, "availability_status": "AVAILABLE"}],
            "verification_references": [],
            "disclosure": {"disclosure_scope": "PUBLIC", "declared_by": "experiment-script"}
        }
        write_jsonl(experience_events_file, exp_evt)

if __name__ == '__main__':
    main()
